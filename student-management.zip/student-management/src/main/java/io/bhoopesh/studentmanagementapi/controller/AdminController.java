package io.bhoopesh.studentmanagementapi.controller;

import io.bhoopesh.studentmanagementapi.model.Student;
import io.bhoopesh.studentmanagementapi.service.DataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/admin")
public class AdminController {

    @Autowired
    private DataService dataService;
    /*
    localhost:8080/admin, get request -> fetch all data
	localhost:8080/admin/{rollNumber}, get -> fetch data for that rollnumber
	localhost:8080/admin, post request -> save the student obj in database
	localhost:8080/admin, put request -> update the student obj in database
	localhost:8080/admin/{rollNumber}, delete request -> delete that student form database
     */

    // 	localhost:8080/admin/2, get -> fetch data for that rollnumber

    @GetMapping(value="/{rollNumber}")
    public Student getStudent(@PathVariable("rollNumber") int rollNumber){
            return dataService.getStudentByRollNumber(rollNumber);
    }


    //create student object
    @PostMapping
    public String addStudent(@RequestBody Student student){
        dataService.addStudent(student);
        return "Student data saved successfully into database";
    }

    //update student object
    @PutMapping
    public String updateStudent(@RequestBody Student student){
        dataService.updateStudent(student);
        return "Student data updated successfully into database";
    }

    // 	localhost:8080/admin/{rollNumber}, delete request -> delete that student form database

    @DeleteMapping(value="/{rollNumber}")
    public String deleteStudent(@PathVariable("rollNumber") int rollNumber){
        dataService.deleteByRollNumber(rollNumber);
        return "Student object with rollnumber " + rollNumber + " deleted sucessfully";
    }

    // get All student for age >= {some value}
    //localhost:3000/admin/age/{age}, get request

    @GetMapping(value = "/age/{age}")
    public List<Student> getStudentByAge(@PathVariable("age") int age){
        return dataService.getStudentsByAge(age);
    }





}
