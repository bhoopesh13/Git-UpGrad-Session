package io.bhoopesh.studentmanagementapi.service;

import io.bhoopesh.studentmanagementapi.model.Student;
import io.bhoopesh.studentmanagementapi.repository.DataRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DataService {

    @Autowired
    private DataRepository dataRepository;

    public Student getStudentByRollNumber(int rollNumber) {
        return dataRepository.findById(rollNumber).get();
    }

    public void addStudent(Student student) {
        // if not exsit, then I will create
        dataRepository.save(student);
    }

    public void updateStudent(Student student) {
        // If exist, the  only I will update
        dataRepository.save(student);
    }

    public void deleteByRollNumber(int rollNumber) {
        dataRepository.deleteById(rollNumber);
    }

    public List<Student> getStudentsByAge(int age) {
        return dataRepository.findStudentByAge(age);
    }
}
