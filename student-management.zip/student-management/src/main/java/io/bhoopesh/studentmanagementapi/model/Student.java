package io.bhoopesh.studentmanagementapi.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Student {

    @Id
    private int rollNumber;
    private String name;
    private int age;
    private int classNumber;
    private int marks;
    private int attendance;
    private boolean hostelResident;

    public Student() {
    }

    public Student(int rollNumber, String name, int age, int classNumber, int marks, int attendance, boolean hostelResident) {
        this.rollNumber = rollNumber;
        this.name = name;
        this.age = age;
        this.classNumber = classNumber;
        this.marks = marks;
        this.attendance = attendance;
        this.hostelResident = hostelResident;
    }

    public int getRollNumber() {
        return rollNumber;
    }

    public void setRollNumber(int rollNumber) {
        this.rollNumber = rollNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getClassNumber() {
        return classNumber;
    }

    public void setClassNumber(int classNumber) {
        this.classNumber = classNumber;
    }

    public int getMarks() {
        return marks;
    }

    public void setMarks(int marks) {
        this.marks = marks;
    }

    public int getAttendance() {
        return attendance;
    }

    public void setAttendance(int attendance) {
        this.attendance = attendance;
    }

    public boolean isHostelResident() {
        return hostelResident;
    }

    public void setHostelResident(boolean hostelResident) {
        this.hostelResident = hostelResident;
    }
}
