package com.bhoopesh.interitance;

public class ITDeparmentEmployee extends Employee{

    String itEmpFixedSalary;
    String itEmpVariableSalary;
    String itSkillSet;

    public void showITEmpSalaryData(){
        System.out.println("Fixed Salary is : " + itEmpFixedSalary +
                            " Variable Salary is : " + itEmpVariableSalary);
    }
}
