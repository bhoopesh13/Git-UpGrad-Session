package com.bhoopesh.interitance;
public class PolymorphismBasic {
    public double sum(double a, int b){
        System.out.println("Calling 1");
        return (a + b);
    }
    public double sum(int a, double b){
        System.out.println("Calling 2");
        return (a + b);
    }
    public static void main(String[] args) {
        PolymorphismBasic obj = new PolymorphismBasic();
        System.out.println(obj.sum(10.2,20));
         System.out.println(obj.sum(10,20.2));
        //System.out.println(obj.sum(10,20));
        // System.out.println(obj.sum(10.2,20.3));




    }
}
