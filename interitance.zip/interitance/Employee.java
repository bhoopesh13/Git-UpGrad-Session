package com.bhoopesh.interitance;

public class Employee {
    int empId;
    String empName;
    String empMobileName;
    String empCity;
    String empState;
    String empCountry;

    public Employee(int empId, String empName, String empMobileName, String empCity, String empState, String empCountry) {
        System.out.println("calling constructor with all parameter");
        this.empId = empId;
        this.empName = empName;
        this.empMobileName = empMobileName;
        this.empCity = empCity;
        this.empState = empState;
        this.empCountry = empCountry;
    }

    public Employee(int empId, String empName) {
        System.out.println("calling constructor with two parameter");
        this.empId = empId;
        this.empName = empName;
    }

    Employee(){
        System.out.println("calling no arg constructor");
    }

    public void showEmpData(){
        System.out.println("EmpName is : " + empName   +
                            " EmpId is :  " + empId);
    }
}


//  Employee emp = new Employee();
// Employee emp = new Employee(11, "A", "1234", "gurgaon", "haryana", "india");
//  Employee emp = new Employee(123, "b");
