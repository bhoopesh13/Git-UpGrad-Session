package com.bhoopesh.interitance;

public class ITEquipment extends ITDeparmentEmployee{
}
