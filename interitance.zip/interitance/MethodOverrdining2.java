package com.bhoopesh.interitance;

public class MethodOverrdining2 extends MethodOverridingExample{

    int c = 30;

    void show(){
        System.out.println("value of a is : "+ a);
        System.out.println("value of b is : "+ b);
        System.out.println("value of c is : "+ c);

    }
}
