package com.bhoopesh.interitance;

public class Driver {
    public static void main(String[] args) {

        Employee emp = new Employee(11, "A", "1234", "gurgaon", "haryana", "india");

        System.out.println("EmpId is :" + emp.empId);
        System.out.println("EmpMob is :" + emp.empMobileName);

        emp.showEmpData();


        ITDeparmentEmployee itEmp1 = new ITDeparmentEmployee();

        itEmp1.itEmpFixedSalary = "5 Lac";
        itEmp1.itEmpVariableSalary = "10% of fix salary";

        itEmp1.showITEmpSalaryData();

        itEmp1.empId = 12345;
        itEmp1.empName = "ABC";

        itEmp1.showEmpData();


        MethodOverrdining2 obj2 = new MethodOverrdining2();
        obj2.show();

        MethodOverridingExample obj3 = new MethodOverridingExample();
        obj3.show();


    }
}
