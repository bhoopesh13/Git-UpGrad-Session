package com.bhoopesh.interitance;

public class MethodOverridingExample {

    int a = 10;
    int b = 20;

    void show(){
        System.out.println("value of a is : "+ a);
        System.out.println("value of b is : "+ a);
    }
}
